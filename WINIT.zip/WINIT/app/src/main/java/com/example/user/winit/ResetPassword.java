package com.example.user.winit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ResetPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
    }
}
